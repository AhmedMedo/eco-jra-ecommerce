export default {
  currency(state) {
    return state.currency;
  },
};
