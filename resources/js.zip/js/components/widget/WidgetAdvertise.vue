<template>
  <div class="widget widget_advertise">
    <router-link to="/blog">
      <img src="../../assets/images/ad.jpg" alt="" />
    </router-link>
  </div>
</template>
