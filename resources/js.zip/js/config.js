export default {
    status: {
        active: 1,
        inactive: 2
    },
    amount_type: {
        percent: 1,
        flat: 2,
    },
    footer_widgets:{
        newsletter_widget:79,
        address_widget:78,
    }
};
